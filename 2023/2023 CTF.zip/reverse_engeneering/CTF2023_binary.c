#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Simple XOR encryption/decryption
void lock(char *input, char *output, const char *key, int length) {
    int keyLength = strlen(key);  // Getting the length of the key
    for(int i = 0; i < length; i++) {
        output[i] = input[i] ^ key[i % keyLength];  // XOR operation and handling key cycling
    }
    output[length] = '\0';  // Null terminate the decoded string
}

// Check password using a non-trivial logic
int authentication(const char *input) {
    const char encodedPassword[] = {62, 55, 56, 44, 0, 23, 74, 16, 93}; // XOR encoded "URAGen!u$"
    char decodedPassword[10];
    lock((char *)encodedPassword, decodedPassword, "key", 9);
    // decodedPassword[10] = '\0';  // Null terminate the decoded string
    // printf("Input received: %s\n", input);
    // printf("Decoded password: %s\n", decodedPassword);

    return strcmp(input, decodedPassword) == 0;
}

// Function to display the CTF flag when the password is correct
void jackpot() {
    const char encodedFlag[] = {19, 20, 53, 8, 71, 82, 20, 17, 16, 32, 96, 50, 1, 111, 75, 3, 48, 4, 108, 45, 27, 52, 115, 14};

    char decodedFlag[46];

    // Decrypting the flag
    lock((char *)encodedFlag, decodedFlag, "P@ssw0rd4CTF2023Ev3n+", 45);
    decodedFlag[24] = '\0';  // Null terminate the decoded flag string

    printf("Here is your Flag: %s\n", decodedFlag);
}

int main() {
    char password[50];

    printf("Enter the password: ");
    scanf("%49s", password);  // Using a width specifier to prevent buffer overflow

    if(authentication(password)) {
        printf("Access granted!\n");
        jackpot();  // Display the decoded CTF flag when the password is correct
    } else {
        printf("Access denied! Try again.\n");
    }

    return 0;
}
